﻿window.JSInteropExt = {};

window.JSInteropExt.saveAsFile = (filename, type, byteBase64) => {
    var link = document.createElement('a');
    link.download = filename;
    link.href = "data:" + type + ";base64," + byteBase64;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
window.JSInteropExt.UpdateSelectedValueInDropdown = (elementid, value, isdisabled) => {
    document.getElementById(elementid).value = value;
    document.getElementById(elementid).disabled = isdisabled;
}
window.JSInteropExt.PublishSuccess = (message) => {
    document.querySelector("#publishSuccessModal").visible = true
    document.getElementById("publishSuccessModal-text").innerHTML = message;
}
window.JSInteropExt.PublishError = (message) => {
    document.querySelector("#publishErrorModal").visible = true
    document.getElementById("publishErrorModal-text").innerHTML = message;
}
window.JSInteropExt.HideConfirm = () => {
    document.querySelector("#publishConfirmModal").visible = false;
}
window.JSInteropExt.HideLogsConfirm = () => {
    document.querySelector('#fullLogsConfirmModal').visible = false;
}

window.JSInteropExt.DisablePublishButton = () => {
    document.getElementById("publish-button").disabled = true;
    document.getElementById("publish-button").setAttribute("color", "secondary");
}
window.JSInteropExt.EnabledPublishButton = () => {
    document.getElementById("publish-button").disabled = false;
    document.getElementById("publish-button").setAttribute("color", "primary");
}

window.JSInteropExt.PauseSuccess = () => {
    document.querySelector("#PauseSuccessModal").visible = true;
}
window.JSInteropExt.PauseError = () => {
    document.querySelector("#PauseErrorModal").visible = true;
}

window.JSInteropExt.ResumeSuccess = () => {
    document.querySelector("#ResumesuccessModal").visible = true;
}
window.JSInteropExt.ResumeError = () => {
    document.querySelector("#ResumeErrorModal").visible = true;
}

window.JSInteropExt.CancelSuccess = () => {
    document.querySelector("#CancelSuccessModal").visible = true;
}
window.JSInteropExt.CancelError = () => {
    document.querySelector("#CancelErrorModal").visible = true;
}

window.JSInteropExt.disablepackagesAvailable = (elementid,isdisabled) => {
    document.getElementById(elementid).disabled = isdisabled;
}

window.JSInteropExt.packagesAvailableValueChange = (Packagevalue) => {
    document.getElementById("PackagesAvailable").value = Packagevalue;
}

window.JSInteropExt.packagesAvailableValueChangeToEmpty = () => {
    document.getElementById("PackagesAvailable").value = "";
}

window.JSInteropExt.availableLogsValueChangeToEmpty = () => {
    document.getElementById("AvailableLogs").value = "";
}
window.JSInteropExt.logsValueChangeToEmpty = () => {
    document.getElementById("Logs").value = "";
}

window.JSInteropExt.downloadFromUrl = (url, fileName) => {
    var link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    link.remove();
}