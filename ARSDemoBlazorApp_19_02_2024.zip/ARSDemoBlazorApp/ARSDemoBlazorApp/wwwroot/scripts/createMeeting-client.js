const baseURL = window.location.href;
console.log("baseURL", baseURL);

const videoSizeMultiplier = 1;

var url = baseURL.split('createMeeting-client.html')[0];
url = "https://pulud6u8je.execute-api.us-east-1.amazonaws.com/Prod/";
var apiUrl = url + "create"; // assumes meetingInfo is using the same API GW
console.log(apiUrl);

var meetingSession;

var screenTileAssociation = []

function getElementOffset(element) {
    let topOffset = element.offsetTop
    let leftOffset = element.offsetLeft
    while (element.offsetParent != null) {
        element = element.offsetParent
        topOffset += element.offsetTop
        leftOffset += element.offsetLeft
    }

    return [topOffset, leftOffset]
}

//*******************************************************************************
// Function:  getMeetingInfo(meetingId)
// Returns: Meeting and Attendee Info
// If meeting exists, returns existing meeting info,
// else starts new meeting and returns that info
// Always creates a new Attendee (limit 250)
//*******************************************************************************
async function getMeetingInfo(meetingId) {
    const options = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        }
    };
    const url = apiUrl + "?m=" + meetingId + "&path=" + '/createMeeting';
    const response = await fetch(url, options);
    return await response.json();
}

async function joinMeetingInfo(meetingId, joineename) {
    let url = `https://pulud6u8je.execute-api.us-east-1.amazonaws.com/Prod/join?m=${meetingId}&e=${joineename}`;
    const options = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        }
    };
    const response = await fetch(url, options);
    return await response.json();
}

function getMouseButtonDescription(buttonId) {
    let button = ""
    if (buttonId == 0) {
        button = "left"
    }
    else if (buttonId == 2) {
        button = "right"
    }
    else if (buttonId == 4) {
        button = "middle"
    }

    return button
}

function changeQuality() {
    var simulcastEnabled = parseInt(document.getElementById("simulcast").value);
    var lowbitrate = parseInt(document.getElementById("lowbitrate").value);
    var lowscale = parseInt(document.getElementById("lowscale").value);
    var lowframerate = parseInt(document.getElementById("lowframerate").value);
    var highbitrate = parseInt(document.getElementById("highbitrate").value);
    var highscale = parseInt(document.getElementById("highscale").value);
    var highframerate = parseInt(document.getElementById("highframerate").value);
    console.log("Quality Changed to: ", lowbitrate, lowscale, lowframerate, highbitrate, highscale, highframerate)
    let videoQualitySettings = {
        SimulcastEnabled: simulcastEnabled == 'true',
        LowBitrate: lowbitrate,
        LowScale: lowscale,
        LowFramerate: lowframerate,
        HighBitrate: highbitrate,
        HighScale: highscale,
        HighFramerate: highframerate,
    }

    meetingSession.audioVideo.realtimeSendDataMessage("VideoQuality", videoQualitySettings)
}

// Note: Pressing the create button multiple times will create multiple attendees  

async function createMeeting() {
    document.oncontextmenu = function () {
        return false;
    }
    var joinElement = document.getElementById('joinname');
    var slAttendees = document.getElementById("slAttendees");
    if (joinElement != null && joinElement != undefined) {
        const joinInfo = await joinMeetingInfo(document.getElementById('externalMeetingId').value, document.getElementById('joinname').value);
        document.getElementById('joinedbyname').innerText = joinInfo.Attendee.ExternalUserId;
        document.getElementById('joinedby').style.display = "block";



        if (joinInfo.Attendee.length == undefined) {
            var option = document.createElement("option"),
                txt = document.createTextNode(joinInfo.Attendee.ExternalUserId);
            option.appendChild(txt);
            option.setAttribute("value", joinInfo.Attendee.AttendeeId);
            slAttendees.insertBefore(option, slAttendees.lastChild);
        }
        else {
            for (var i = 0; i < joinInfo.Attendee.length; i++) {
                var option = document.createElement("option"),
                    txt = document.createTextNode(joinInfo.Attendee.ExternalUserId[i]);
                option.appendChild(txt);
                option.setAttribute("value", joinInfo.Attendee.AttendeeId[i]);
                slAttendees.insertBefore(option, slAttendees.lastChild);
            }
        }

    }
    //  const data = await getMeetingInfo("testMeeting"); // Fetch the meeting and attendee data
    let meetingToJoin = document.getElementById('externalMeetingId').value;
    const data = await getMeetingInfo(meetingToJoin); // Fetch the meeting and attendee data
    console.log('Success getting meeting info ', data);

    const meeting = data.Meeting;
    const attendee = data.Attendee;
    
    if (data.Attendee.length == undefined) {
        var option = document.createElement("option"),
            txt = document.createTextNode(data.Attendee.ExternalUserId);
        option.appendChild(txt);
        option.setAttribute("value", data.Attendee.AttendeeId);
        slAttendees.insertBefore(option, slAttendees.lastChild);
    }
    else {
        for (var i = 0; i < data.Attendee.length; i++) {
            var option = document.createElement("option"),
                txt = document.createTextNode(data.Attendee.ExternalUserId[i]);
            option.appendChild(txt);
            option.setAttribute("value", data.Attendee.AttendeeId[i]);
            slAttendees.insertBefore(option, slAttendees.lastChild);
        }
    }

    document.getElementById('meetingId').value = meeting.MeetingId;
    document.getElementById('attendeeId').value = attendee.AttendeeId;
    document.getElementById('externalMeetingId').value = meeting.ExternalMeetingId;

    const logger = new ChimeSDK.ConsoleLogger('MyLogger');
    const deviceController = new ChimeSDK.DefaultDeviceController(logger);
    console.log('deviceController', deviceController);

    const configuration = new ChimeSDK.MeetingSessionConfiguration(meeting, attendee);
    console.log('configuration ', configuration);

    meetingSession = new ChimeSDK.DefaultMeetingSession(configuration, logger, deviceController);
    console.log('meetingSession ', meetingSession);

    const presentAttendeeId = meetingSession.configuration.credentials.attendeeId;
    console.log('presentAttendeeId - ', presentAttendeeId);

    const browserBehaviour = new ChimeSDK.DefaultBrowserBehavior();
    console.log('supportSetSinkId is ', browserBehaviour.supportsSetSinkId());

    try {

        await meetingSession.audioVideo.startAudioInput(null);  // v3
        console.log('empty set for chooseAudioInputDevice');

    } catch (err) {
        // handle error - unable to acquire video or audio device perhaps due to permissions blocking or chromium bug on retrieving device label
        // see setupDeviceLabelTrigger() on https://github.com/aws/amazon-chime-sdk-js/blob/main/demos/browser/app/meetingV2/meetingV2.ts
        console.log('Try Catch Error - unable to acquire device - ', err);
    }

    const videoElementScreenShare = document.getElementById('video-tile-screen-share');
    const videoCanvasShare1 = document.getElementById('videoCanvas1');
    const videoCanvasShare2 = document.getElementById('videoCanvas2');
    
    const observer = {
        audioVideoDidStart: () => {
            logger.debug('Started');
            console.log("audioVideoDidStart fired")
        },

        videoTileDidUpdate: tileState => {
            console.log("videoTileDidUpdate fired", tileState)
            console.log(JSON.stringify(tileState))
            if (!tileState.boundAttendeeId) {
                return;
            }
            if (tileState.localTile) {
                console.log("local tile")
            } else if (tileState.isContent) {
                console.log("Shared video stream: ", tileState)
                console.log("Received Content Share")
                if (!document.getElementById(tileState.tileId)) {
                    console.log("Adding content share to tile")
                    console.log("tileState: " + tileState)
                   
                    const node = document.createElement("video");
                    node.id = tileState.tileId;
                    //node.setAttribute('width', 1000 * videoSizeMultiplier);
                    //node.setAttribute('height', 600 * videoSizeMultiplier);
                    //node.setAttribute('object-fit', 'cover');
                    //node.setAttribute('class', 'videoInsert');
                    videoElementScreenShare.appendChild(node);
                    const videoElementNew = document.getElementById(tileState.tileId);
                    meetingSession.audioVideo.bindVideoElement(tileState.tileId, videoElementNew);

                    addMouseListeners(node)

                    var screen = "Originator";
                    if (screen != null & screen != '') {
                        var monitorNum = parseInt(screen.split(':')[1])
                        screenTileAssociation[tileState.tileId] = monitorNum
                    }
                }
            }
        },
        videoTileWasRemoved: tileId => {
            const videoElementRemoved = document.getElementById(tileId);
            videoElementRemoved?.remove();
        },
        audioVideoDidStop: async sessionStatus => {  // v3
            await meetingSession.audioVideo.stopAudioInput();

            // Or use the destroy API to call stopAudioInput and stopVideoInput.
            meetingSession.deviceController.destroy();
        },
    };

    meetingSession.audioVideo.addObserver(observer);
    meetingSession.audioVideo.start();
    meetingSession.audioVideo.startLocalVideoTile();

    //let count = 0;
    //meetingSession.audioVideo.realtimeSubscribeToReceiveDataMessage("BasicDemo", (dataMessage) => {

    //    const now = (new Date()).getTime();
    //    var currentdate = new Date();
    //    var datetime = "Last Sync: " + currentdate.getDate() + "/"
    //        + (currentdate.getMonth() + 1) + "/"
    //        + currentdate.getFullYear() + " @ "
    //        + currentdate.getHours() + ":"
    //        + currentdate.getMinutes() + ":"
    //        + currentdate.getSeconds();
    //    let utf8decoder = new TextDecoder()
    //    const jsonStr = utf8decoder.decode(dataMessage.data)
        

    //    //const sent = jsonStr;
    //    //const node1 = document.createElement("video");
    //    //node1.id = count + 1;
    //    //node1.innerHTML = sent + " " + datetime + "</br>";
    //    //node1.setAttribute('width', 1920 * videoSizeMultiplier);
    //    //node1.setAttribute('height', 1080 * videoSizeMultiplier);

    //    //videoCanvasShare.appendChild(node1);
    //    //const videoElementNew = document.getElementById(count + 1);
    //    //meetingSession.audioVideo.bindVideoElement(count + 1, videoElementNew);




    //    const sent = jsonStr;
    //   // const node1 = document.createElement("video");
    //    //node1.id = count + 1;
    //    const ctx = videoCanvasShare1.getContext("2d");
    //    ctx.font = "10px Arial";
    //    ctx.fillText(sent, 10, 50);
    //    //node1.innerHTML = sent + " " + datetime + "</br>";
    //    //videoCanvasShare1.setAttribute('width', 1920 * videoSizeMultiplier);
    //    //videoCanvasShare1.setAttribute('height', 1080 * videoSizeMultiplier);

    //    //videoCanvasShare.appendChild(node1);
    //    //const videoElementNew = document.getElementById(count + 1);
    //    //meetingSession.audioVideo.bindVideoElement(count + 1, videoCanvasShare);

    //    addMouseListeners(videoCanvasShare1);

    //    // const node = document.createElement("p");     
    //    // node.id = "content" + now;
    //    // node.innerHTML = sent + " " + datetime;
    //    // contentScreenShare.appendChild(node);
    //    //document.getElementById("content-tile-screen-share").innerText =sent; 

    //    console.log("videoCanvasShare1 Data Messages and Timestamp: ", sent + " " + datetime);
    //})

    //meetingSession.audioVideo.realtimeSubscribeToReceiveDataMessage("BasicDemo1", (dataMessage) => {

    //    const now = (new Date()).getTime();
    //    var currentdate = new Date();
    //    var datetime = "Last Sync: " + currentdate.getDate() + "/"
    //        + (currentdate.getMonth() + 1) + "/"
    //        + currentdate.getFullYear() + " @ "
    //        + currentdate.getHours() + ":"
    //        + currentdate.getMinutes() + ":"
    //        + currentdate.getSeconds();
    //    let utf8decoder = new TextDecoder()
    //    const jsonStr = utf8decoder.decode(dataMessage.data)


    //    //const sent = jsonStr;
    //    //const node1 = document.createElement("video");
    //    //node1.id = count + 1;
    //    //node1.innerHTML = sent + " " + datetime + "</br>";
    //    //node1.setAttribute('width', 1920 * videoSizeMultiplier);
    //    //node1.setAttribute('height', 1080 * videoSizeMultiplier);

    //    //videoCanvasShare.appendChild(node1);
    //    //const videoElementNew = document.getElementById(count + 1);
    //    //meetingSession.audioVideo.bindVideoElement(count + 1, videoElementNew);




    //    const sent = jsonStr;
    //    // const node1 = document.createElement("video");
    //    //node1.id = count + 1;
    //    const ctx = videoCanvasShare2.getContext("2d");
    //    ctx.font = "10px Arial";
    //    ctx.fillText(sent, 10, 50);
    //    //node1.innerHTML = sent + " " + datetime + "</br>";
    //    videoCanvasShare2.setAttribute('width', 1920 * videoSizeMultiplier);
    //    videoCanvasShare2.setAttribute('height', 1080 * videoSizeMultiplier);

    //    //videoCanvasShare.appendChild(node1);
    //    //const videoElementNew = document.getElementById(count + 1);
    //    //meetingSession.audioVideo.bindVideoElement(count + 1, videoCanvasShare);

    //    addMouseListeners(videoCanvasShare2);

    //    // const node = document.createElement("p");     
    //    // node.id = "content" + now;
    //    // node.innerHTML = sent + " " + datetime;
    //    // contentScreenShare.appendChild(node);
    //    //document.getElementById("content-tile-screen-share").innerText =sent; 

    //    console.log("videoCanvasShare2 Data Messages and Timestamp: ", sent + " " + datetime);
    //})

}



function getMonitorNumber(nodeId) {
    var tileId = parseInt(nodeId)
    return screenTileAssociation[tileId]
}

function addMouseListeners(node) {
    // send message on a mouse move
    node.addEventListener("mousemove", (e) => {
        // console.log("mouseMove event: ", e)
        let curNode = e.target;
        if (curNode != null) {
            //var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
            var monitorNum = getMonitorNumber(curNode.id)
            var rect = e.target.getBoundingClientRect();
            var percentX = e.clientX - rect.left; //x position within the element.
            var percentY = e.clientY - rect.top;  //y position within the element.
            // let [top, left] = getElementOffset(curNode)
            // let curX = e.pageX - left;
            // let curY = e.pageY - top;
            // console.log("Pixels from left Edge:", curX)
            // console.log("Pixels from top Edge:", curY)
            // let curWidth = curNode.width
            // let curHeight = curNode.height
            // let percentX = parseFloat(curX) / parseFloat(curWidth)
            // let percentY = parseFloat(curY) / parseFloat(curHeight)
            // console.log("Percentage from left Edge:", percentX)
            // console.log("Percentage from top Edge:", percentY)
            let mouseAction = {
                eventId: 'WM_MOUSEMOVE',
                monitor: 1,
                xPos: percentX,
                yPos: percentY,
                keyCode: 0,
                message:""
            }
            meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
        }
    }, { passive: false })

    // send message on a left button click
    node.addEventListener("click", (e) => {
       // const video = document.getElementsByTagName('video');
        console.log("click event: ", e)
        let button = getMouseButtonDescription(e.button)
        var rect = e.target.getBoundingClientRect();
        var x = e.clientX - rect.left; //x position within the element.
        var y = e.clientY - rect.top;  //y position within the element.
        let curNode = e.target;
        if (curNode != null) {
            //var [curX, curY] = getMousePosition(curNode, e.pageX, e.pageY)

            var monitorNum = getMonitorNumber(curNode.id)
            let mouseAction = {
                eventId: 'WM_LBUTTONDOWN',
                monitor: 1,
                xPos: x,
                yPos: y,
                keyCode: 0,
                message: ""
            }
            meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
        }
    }, { passive: false })

    // send message on a mouse button down
     //node.addEventListener("mousedown", (e) => {
     //  console.log("mouse down event: ", e)
     //  let button = getMouseButtonDescription(e.button)
     //  let curNode = e.target;
     //  if (curNode != null) {
     //    var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
     //    var monitorNum = getMonitorNumber(curNode.id)
     //    let mouseAction = {
     //      Action: 'mousedown',
     //      Button: button,
     //      Monitor: monitorNum,
     //      PercentX: percentX,
     //      PercentY: percentY,
     //      KeyCode: -1,
     //    }
     //    meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
     //  }
     //}, { passive: false })

     //node.addEventListener("mouseup", (e) => {
     //  console.log("mouse up event: ", e)
     //  let button = getMouseButtonDescription(e.button)
     //  let curNode = e.target;
     //  if (curNode != null) {
     //    var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
     //    var monitorNum = getMonitorNumber(curNode.id)
     //    let mouseAction = {
     //      Action: 'mouseup',
     //      Button: button,
     //      Monitor: monitorNum,  
     //      PercentX: percentX,
     //      PercentY: percentY,
     //      KeyCode: -1,
     //    }
     //    meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
     //  }
     //}, { passive: false })

    // send message on a left button click
    node.addEventListener("contextmenu", (e) => {
        console.log("right click event: ", e)
        let curNode = e.target;
        if (curNode != null) {
            var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
            var monitorNum = getMonitorNumber(curNode.id)
            let mouseAction = {
                eventId: 'WM_RBUTTONDOWN',
                monitor: 1,
                xPos: percentX,
                yPos: percentY,
                keyCode: -1,
                message: ""
            }
            meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
        }
    }, { passive: false })

    //var div = document.querySelector("video-tile-screen-share");
    //div.addEventListener("keydown", handleKeyEvent);

    document.querySelector("#video-tile-screen-share").addEventListener("keydown", (e) => {
        console.log("key down event: ", e)
            let ascii, key = e.key;
    if (key.length == 1) {
        ascii = key.charCodeAt(0);
        if (ascii < 128 && e.ctrlKey) {
            ascii = ascii & 0x1f;
        }
        }
        console.log("ascii:" + ascii);
        var message = "";
        if (e.shiftKey) {
            message = "shift";
            //var character = mapKeyPressToActualCharacter(true, e.keyCode);
            //console.log("character is: " + character);
        }
        else if (e.ctrlKey) {
            message = "control";
        }
        else {
            message = "";
        }
        let curNode = e.target;
        //var rect = e.target.getBoundingClientRect();
        //var percentX = e.clientX - rect.left; //x position within the element.
        //var percentY = e.clientY - rect.top;  //y position within the element.
        //var perX = e.target.offsetLeft;
        //var perY = e.target.offsetTop;
        if (curNode != null) {
            let mouseAction = {
                eventId: 'WM_KEYDOWN',
                monitor: 1,
                xPos: 0,
                yPos: 0,
                keyCode: ascii,
                message: "",
            }
            meetingSession.audioVideo.realtimeSendDataMessage("KeyBoardAction", mouseAction)
        }
    }, { passive: false })

    //document.querySelector("#video-tile-screen-share").addEventListener("keyup", (e) => {
    //    console.log("key up event: ", e)
    //    let curNode = e.target;
    //    var rect = e.target.getBoundingClientRect();
    //    var percentX = e.clientX - rect.left; //x position within the element.
    //    var percentY = e.clientY - rect.top;  //y position within the element.
    //    var perX = e.target.offsetLeft;
    //    var perY = e.target.offsetTop;
    //    if (curNode != null) {
    //        let mouseAction = {
    //            eventId: 'WM_KEYUP',
    //            monitor: 1,
    //            xPos: 0,
    //            yPos: 0,
    //            keyCode: e.keyCode,
    //            message: ""
    //        }
    //        meetingSession.audioVideo.realtimeSendDataMessage("KeyBoardAction", mouseAction)
    //    }
    //}, { passive: false })
}

//function handleKeyEvent(evt) {
//    setTimeout(function () {
//        console.log(evt.type, window.getSelection().getRangeAt(0).startOffset);
//    }, 0);
//}
function getMousePosition(node, pageX, pageY) {
    let [top, left] = getElementOffset(node)
    let curX = pageX - left;
    let curY = pageY - top;
    // console.log("Pixels from left Edge:", curX)
    // console.log("Pixels from top Edge:", curY)
    let curWidth = node.offsetWidth
    let curHeight = node.offsetHeight
    let percentX = parseFloat(curX) / parseFloat(curWidth)
    let percentY = parseFloat(curY) / parseFloat(curHeight)
    return [curX, curY]
}


function ShareMeeting() {
    var joinApiUrl = url + "join?m=" + document.getElementById('externalMeetingId').value; // assumes meetingInfo is using the same API GW
    localStorage.setItem("joinApiUrl", joinApiUrl);
    window.open(
        'Join',
        '_blank' // <- This is what makes it open in a new window.
    );
}

function changeMonitors(selectObject) {
    var value = selectObject.value;
    if (value == "1") {
        document.getElementById('videoCanvas2').style.display = "none";
    }
    else if (value == "2") {
        document.getElementById('videoCanvas2').style.display = "inline-block";
    }
}

//window.addEventListener('keydown', e => {
//    let ascii, key = e.key;
//    if (key.length == 1) {
//        ascii = key.charCodeAt(0);
//        if (ascii < 128 && e.ctrlKey) {
//            ascii = ascii & 0x1f;
//        }
//    }
//    if (typeof ascii == "number" && ascii < 128) {
//        console.log(`ASCII code ${ascii} entered from keyboard`);
//    }
//    else {
//        console.log(key + " is not in the ASCII character set");
//    }
//});
//function mapKeyPressToActualCharacter(isShiftKey, characterCode) {
//    if (characterCode === 27 || characterCode === 8 || characterCode === 9 || characterCode === 20 || characterCode === 16 || characterCode === 17 || characterCode === 91 || characterCode === 13 || characterCode === 92 || characterCode === 18) {
//        return false;
//    }
//    if (typeof isShiftKey != "boolean" || typeof characterCode != "number") {
//        return false;
//    }
//    var characterMap = [];
//    characterMap[192] = "~";
//    characterMap[49] = "!";
//    characterMap[50] = "@";
//    characterMap[51] = "#";
//    characterMap[52] = "$";
//    characterMap[53] = "%";
//    characterMap[54] = "^";
//    characterMap[55] = "&";
//    characterMap[56] = "*";
//    characterMap[57] = "(";
//    characterMap[48] = ")";
//    characterMap[109] = "_";
//    characterMap[107] = "+";
//    characterMap[219] = "{";
//    characterMap[221] = "}";
//    characterMap[220] = "|";
//    characterMap[59] = ":";
//    characterMap[222] = "\"";
//    characterMap[188] = "<";
//    characterMap[190] = ">";
//    characterMap[191] = "?";
//    characterMap[32] = " ";
//    var character = "";
//    if (isShiftKey) {
//        if (characterCode >= 65 && characterCode <= 90) {
//            character = String.fromCharCode(characterCode);
//        } else {
//            character = characterMap[characterCode];
//        }
//    } else {
//        if (characterCode >= 65 && characterCode <= 90) {
//            character = String.fromCharCode(characterCode).toLowerCase();
//        } else {
//            character = String.fromCharCode(characterCode);
//        }
//    }
//    return character;
//}


