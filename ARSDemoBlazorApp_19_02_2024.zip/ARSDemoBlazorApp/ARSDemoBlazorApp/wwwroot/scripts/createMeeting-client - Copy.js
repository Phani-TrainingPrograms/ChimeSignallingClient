import('./sdk/amazon-chime-sdk.min.js');
/*global fetch*/

/*global ChimeSDK*/

const baseURL = window.location.href;
console.log("baseURL", baseURL);

const videoSizeMultiplier = .9;

var url = baseURL.split('createMeeting-client.html')[0];
url = "https://pulud6u8je.execute-api.us-east-1.amazonaws.com/Prod/";
var apiUrl = url+"create"; // assumes meetingInfo is using the same API GW
console.log(apiUrl);

var meetingSession;

var screenTileAssociation = []

function getElementOffset (element) {
  let topOffset = element.offsetTop
  let leftOffset = element.offsetLeft
  while (element.offsetParent != null)
  {
    element = element.offsetParent
    topOffset += element.offsetTop
    leftOffset += element.offsetLeft
  }

  return [topOffset, leftOffset]
}

//*******************************************************************************
// Function:  getMeetingInfo(meetingId)
// Returns: Meeting and Attendee Info
// If meeting exists, returns existing meeting info,
// else starts new meeting and returns that info
// Always creates a new Attendee (limit 250)
//*******************************************************************************
async function getMeetingInfo(meetingId) {
    const options = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    };
    const url = apiUrl + "?m=" + meetingId +"&path="+'/createMeeting';
    const response = await fetch(url, options);
    return await response.json();
}

function getMouseButtonDescription(buttonId)
{
  let button = ""
  if (buttonId == 0)
  {
    button = "left"
  }
  else if (buttonId == 2)
  {
    button = "right"
  }
  else if (buttonId == 4)
  {
    button = "middle"
  }

  return button
}

function changeQuality() {
  var simulcastEnabled = parseInt(document.getElementById("simulcast").value);
  var lowbitrate = parseInt(document.getElementById("lowbitrate").value);
  var lowscale = parseInt(document.getElementById("lowscale").value);
  var lowframerate = parseInt(document.getElementById("lowframerate").value);
  var highbitrate = parseInt(document.getElementById("highbitrate").value);
  var highscale = parseInt(document.getElementById("highscale").value);
  var highframerate = parseInt(document.getElementById("highframerate").value);
  console.log("Quality Changed to: ", lowbitrate, lowscale, lowframerate, highbitrate, highscale, highframerate)
  let videoQualitySettings = {
    SimulcastEnabled: simulcastEnabled == 'true',
    LowBitrate: lowbitrate,
    LowScale: lowscale,
    LowFramerate: lowframerate,
    HighBitrate: highbitrate,
    HighScale: highscale,
    HighFramerate: highframerate,
  }

  meetingSession.audioVideo.realtimeSendDataMessage("VideoQuality", videoQualitySettings)
}

// Note: Pressing the create button multiple times will create multiple attendees  

async function createMeeting() {
  document.oncontextmenu = function() {
    return false;
  }
  
//  const data = await getMeetingInfo("testMeeting"); // Fetch the meeting and attendee data
  let meetingToJoin = document.getElementById('externalMeetingId').value;
  const data = await getMeetingInfo(meetingToJoin); // Fetch the meeting and attendee data
  console.log( 'Success getting meeting info ', data );
  
  const meeting = data.Meeting;
  const attendee = data.Attendee;

  document.getElementById('meetingId').value = meeting.MeetingId;
  document.getElementById('attendeeId').value = attendee.AttendeeId;
  document.getElementById('externalMeetingId').value = meeting.ExternalMeetingId;

  const logger = new ChimeSDK.ConsoleLogger('MyLogger');
  const deviceController = new ChimeSDK.DefaultDeviceController(logger);
  console.log('deviceController', deviceController);

  const configuration = new ChimeSDK.MeetingSessionConfiguration(meeting, attendee);
  console.log('configuration ', configuration);
  
  meetingSession = new ChimeSDK.DefaultMeetingSession(configuration, logger, deviceController);
  console.log('meetingSession ', meetingSession);
    
  const presentAttendeeId = meetingSession.configuration.credentials.attendeeId;
  console.log('presentAttendeeId - ',presentAttendeeId);

  const browserBehaviour = new ChimeSDK.DefaultBrowserBehavior();
  console.log('supportSetSinkId is ', browserBehaviour.supportsSetSinkId());

  try {

    await meetingSession.audioVideo.startAudioInput(null);  // v3
    console.log('empty set for chooseAudioInputDevice');

  } catch (err) {
    // handle error - unable to acquire video or audio device perhaps due to permissions blocking or chromium bug on retrieving device label
    // see setupDeviceLabelTrigger() on https://github.com/aws/amazon-chime-sdk-js/blob/main/demos/browser/app/meetingV2/meetingV2.ts
    console.log('Try Catch Error - unable to acquire device - ', err);
  }

  const videoElementScreenShare = document.getElementById('video-tile-screen-share');

  const observer = {
    audioVideoDidStart: () => {
      logger.debug('Started');
      console.log("audioVideoDidStart fired")
    },
    
    videoTileDidUpdate: tileState => {
      console.log("videoTileDidUpdate fired", tileState)
      if (!tileState.boundAttendeeId) {
        return;
      }
      if (tileState.localTile){
        console.log("local tile")
      } else if (tileState.isContent) {
        console.log("Shared video stream: ", tileState)
        console.log("Received Content Share")
        if (!document.getElementById(tileState.tileId)) {
          console.log("Adding content share to tile")
          const node = document.createElement("video");     
          node.id = tileState.tileId;
          node.setAttribute('width', 1920 * videoSizeMultiplier);
          node.setAttribute('height', 1080 * videoSizeMultiplier);

          videoElementScreenShare.appendChild(node);
          const videoElementNew = document.getElementById(tileState.tileId);
          meetingSession.audioVideo.bindVideoElement(tileState.tileId, videoElementNew);

          addMouseListeners(node)

          var screen = tileState.boundExternalUserId
          if (screen != null & screen != '') {
            var monitorNum = parseInt(screen.split(':')[1])
            screenTileAssociation[tileState.tileId] = monitorNum
          } 
        }
      }   
    },
    videoTileWasRemoved: tileId => {
      const videoElementRemoved = document.getElementById(tileId);
      videoElementRemoved?.remove();
    },
    audioVideoDidStop: async sessionStatus => {  // v3
        await meetingSession.audioVideo.stopAudioInput();

        // Or use the destroy API to call stopAudioInput and stopVideoInput.
        meetingSession.deviceController.destroy();
    },
  };

  meetingSession.audioVideo.addObserver(observer);
  meetingSession.audioVideo.start();
  meetingSession.audioVideo.startLocalVideoTile();

  var bodyNode = document.getElementsByTagName("BODY")[0];
  bodyNode.addEventListener("keydown", (e) => {
    console.log("key down event: ", e)
    let curNode = e.target;
    if (curNode != null) {
      let mouseAction = {
        Action: 'keydown',
        Button: '',
        Monitor: 0,
        PercentX: 0,
        PercentY: 0,
        KeyCode: e.keyCode,
      }
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })

  bodyNode.addEventListener("keyup", (e) => {
    console.log("key up event: ", e)
    let curNode = e.target;
    if (curNode != null) {
      let mouseAction = {
        Action: 'keyup',
        Button: '',
        Monitor: 0,
        PercentX: 0,
        PercentY: 0,
        KeyCode: e.keyCode,
      }
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })


  // meetingSession.audioVideo.realtimeSubscribeToReceiveDataMessage("LatencyCheck", (e) => {
  //   const now = (new Date()).getTime();
  //   let utf8decoder = new TextDecoder()
  //   const jsonStr = utf8decoder.decode(e.data)
  //   var jsonObj = JSON.parse(jsonStr)

  //   const sent = jsonObj;

  //   console.log("Sent Timestamp: ", sent)
  //   console.log("Local machine time: ", now)

  // })

}



function getMonitorNumber(nodeId) {
  var tileId = parseInt(nodeId)
  return screenTileAssociation[tileId]
}

function addMouseListeners(node) {
  // send message on a mouse move
  node.addEventListener("mousemove", (e) => {
    // console.log("mouseMove event: ", e)
    let curNode = e.target;
    if (curNode != null) {
      var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
      var monitorNum = getMonitorNumber(curNode.id)
      // let [top, left] = getElementOffset(curNode)
      // let curX = e.pageX - left;
      // let curY = e.pageY - top;
      // console.log("Pixels from left Edge:", curX)
      // console.log("Pixels from top Edge:", curY)
      // let curWidth = curNode.width
      // let curHeight = curNode.height
      // let percentX = parseFloat(curX) / parseFloat(curWidth)
      // let percentY = parseFloat(curY) / parseFloat(curHeight)
      // console.log("Percentage from left Edge:", percentX)
      // console.log("Percentage from top Edge:", percentY)
      let mouseAction = {
        Action: 'move',
        Button: 'none',
        Monitor: monitorNum,
        PercentX: percentX,
        PercentY: percentY,
        KeyCode: -1,
        // TimeStamp: (new Date()).getTime(),
      }
      // console.log("Sending Mouse Action:", mouseAction)
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })

  // send message on a left button click
  node.addEventListener("click", (e) => {
    console.log("click event: ", e)
    let button = getMouseButtonDescription(e.button)
    let curNode = e.target;
    if (curNode != null) {
      var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
      var monitorNum = getMonitorNumber(curNode.id)
      let mouseAction = {
        Action: 'click',
        Button: button,
        Monitor: monitorNum,
        PercentX: percentX,
        PercentY: percentY,
        KeyCode: -1,
      }
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })

  // send message on a mouse button down
  node.addEventListener("mousedown", (e) => {
    console.log("mouse down event: ", e)
    let button = getMouseButtonDescription(e.button)
    let curNode = e.target;
    if (curNode != null) {
      var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
      var monitorNum = getMonitorNumber(curNode.id)
      let mouseAction = {
        Action: 'mousedown',
        Button: button,
        Monitor: monitorNum,
        PercentX: percentX,
        PercentY: percentY,
        KeyCode: -1,
      }
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })

  node.addEventListener("mouseup", (e) => {
    console.log("mouse up event: ", e)
    let button = getMouseButtonDescription(e.button)
    let curNode = e.target;
    if (curNode != null) {
      var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
      var monitorNum = getMonitorNumber(curNode.id)
      let mouseAction = {
        Action: 'mouseup',
        Button: button,
        Monitor: monitorNum,
        PercentX: percentX,
        PercentY: percentY,
        KeyCode: -1,
      }
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })

  // send message on a left button click
  node.addEventListener("contextmenu", (e) => {
    console.log("right click event: ", e)
    let curNode = e.target;
    if (curNode != null) {
      var [percentX, percentY] = getMousePosition(curNode, e.pageX, e.pageY)
      var monitorNum = getMonitorNumber(curNode.id)
      let mouseAction = {
        Action: 'click',
        Button: 'right',
        Monitor: monitorNum,
        PercentX: percentX,
        PercentY: percentY,
        KeyCode: -1,
        // TimeStamp: (new Date()).getTime(),
      }
      meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
    }
  }, { passive: false })

  // send message on a left button click
  // node.addEventListener("keydown", (e) => {
  //   console.log("key down event: ", e)
  //   let curNode = e.target;
  //   if (curNode != null) {
  //     let mouseAction = {
  //       Action: 'keydown',
  //       Button: '',
  //       Monitor: 1,
  //       PercentX: 0,
  //       PercentY: 0,
  //       KeyCode: e.code,
  //     }
  //     meetingSession.audioVideo.realtimeSendDataMessage("MouseAction", mouseAction)
  //   }
  // }, { passive: false })
}

function getMousePosition(node, pageX, pageY) {
  let [top, left] = getElementOffset(node)
  let curX = pageX - left;
  let curY = pageY - top;
  // console.log("Pixels from left Edge:", curX)
  // console.log("Pixels from top Edge:", curY)
  let curWidth = node.width
  let curHeight = node.height
  let percentX = parseFloat(curX) / parseFloat(curWidth)
  let percentY = parseFloat(curY) / parseFloat(curHeight)
  return [percentX, percentY]
}

function ShareMeeting() {
    var joinApiUrl = url + "join?m=" + document.getElementById('externalMeetingId').value; // assumes meetingInfo is using the same API GW
    /* window.open(apiUrl, "_blank");*/
    //return joinApiUrl;
    localStorage.setItem("joinApiUrl", joinApiUrl);
    //location.href = 'Join';
    window.open(
        'Join',
        '_blank' // <- This is what makes it open in a new window.
    );

    //window.location = "Join?joinlink="+joinApiUrl;
}