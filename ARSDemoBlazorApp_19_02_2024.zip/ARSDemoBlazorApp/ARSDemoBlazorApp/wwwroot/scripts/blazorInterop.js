﻿var interopFunctions = interopFunctions || {}

//#region Register Blazor components for JavaScript interop communication
interopFunctions.registerAccessbarComponent = (dotnetObj) => {
    interopFunctions.accessbarComponent = dotnetObj;
}

interopFunctions.registerNavigationComponent = (dotnetObj) => {
    interopFunctions.navigationComponent = dotnetObj;
}

interopFunctions.registerLoginComponent = (dotnetObj) => {
    interopFunctions.loginComponent = dotnetObj;
}

interopFunctions.registerAuthenticationComponent = (dotnetObj) => {
    interopFunctions.authenticationComponent = dotnetObj;
}

interopFunctions.registerMainLayoutComponent = (dotnetObj) => {
    interopFunctions.mainLayoutComponent = dotnetObj;
}

interopFunctions.registerSearchDevicesComponent = (dotnetObj) => {
    interopFunctions.searchDevicesComponent = dotnetObj;
}

interopFunctions.registerRegistrationComponent = (dotnetObj) => {
    interopFunctions.registrationComponent = dotnetObj;
}
interopFunctions.registerSoftwareDistributionComponent = (dotnetObj) => {
    interopFunctions.softwareDistributionComponent = dotnetObj;
}
//#endregion

//#region Call JavaScript method from Blazor components
interopFunctions.getTheme = () => {
    val = document.getElementById('page').getAttribute('theme');

    // Send theme value to accessbarComponent through SetTheme method
    interopFunctions.accessbarComponent.invokeMethodAsync('SetTheme', val);
}

interopFunctions.changeTheme = () => {
    ChangeTheme();
}

function ChangeTheme(theme) {
    if (theme == "dark") {
        document.getElementById('page').setAttribute('theme', 'dark')
    }
    else {
        document.getElementById('page').setAttribute('theme', 'light')
    }
}

// Define navigations
interopFunctions.navigateTo = (navName) => {
    if (navName == "searchdevices") {
        document.getElementById('search-devices').setAttribute('active', '');
        document.getElementById('registration').removeAttribute('active');
        document.getElementById('software-distribution').removeAttribute('active');
    }
    else if (navName == "registration") {
        document.getElementById('search-devices').removeAttribute('active');
        document.getElementById('registration').setAttribute('active', '');
        document.getElementById('software-distribution').removeAttribute('active');
    }
    else if (navName == "softwaredistribution") {
        document.getElementById('search-devices').removeAttribute('active');
        document.getElementById('registration').removeAttribute('active');
        document.getElementById('software-distribution').setAttribute('active', '');
    }
}

// Register custom event listeners
interopFunctions.customEvent = (customEventName) => {
    if (customEventName == "sh-dropdown-value-changed") {
        console.log(document.querySelector('sh-dropdown'));
        document.querySelector('sh-dropdown').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.searchDevicesComponent.invokeMethodAsync('OnDropDownValueChanged', e.target.value);
        })
    }
    if (customEventName == "search-devices-clear") {
        console.log("search-devices-clear is called");
        console.log(document.querySelector('search-devices-search'));
        document.getElementById('search-devices-search').addEventListener("clearsearch", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.searchDevicesComponent.invokeMethodAsync('SearchDevicesSearchClearedAsync');
        });
    }
    if (customEventName == "registration-search-clear") {
        console.log("registration-search-clear is called");
        console.log(document.querySelector('registration-search'));
        document.getElementById('registration-search').addEventListener("clearsearch", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.registrationComponent.invokeMethodAsync('RegistrationSearchClearedAsync');
        });
    }
    if (customEventName == "sh-dropdown-sf-uinames-value-changed") {
        console.log(document.querySelector('#uinames-dropdown'));
        document.querySelector('#uinames-dropdown').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.softwareDistributionComponent.invokeMethodAsync('OnUINameValueChanged', e.target.value);
        });
    }
    if (customEventName == "sh-dropdown-sf-packages-value-changed") {
        console.log(document.querySelector('availablepackages-dropdown'));
        document.querySelector('#availablepackages-dropdown').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.softwareDistributionComponent.invokeMethodAsync('OnPackagesValueChanged', e.target.value);
        });
    }
    if (customEventName == "sh-dropdown-sf-timeout-value-changed") {
        console.log(document.querySelector('transfertimeout-dropdown'));
        document.querySelector('#transfertimeout-dropdown').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.softwareDistributionComponent.invokeMethodAsync('OnTimeoutValueChanged', e.target.value);
        });
    }
    if (customEventName == "sh-dropdown-packages-value-changed") {
        console.log(document.querySelector('PackagesAvailable'));
        document.querySelector('#PackagesAvailable').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.searchDevicesComponent.invokeMethodAsync('OnPackageValueChanged', e.target.value);
        });
    }
    if (customEventName == "sh-dropdown-logs-value-changed") {
        console.log(document.querySelector('Logs'));
        document.querySelector('#Logs').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.searchDevicesComponent.invokeMethodAsync('OnLogValueChanged', e.target.value);
        });
    }
    if (customEventName == "sh-dropdown-availablelogs-value-changed") {
        console.log(document.querySelector('AvailableLogs'));
        document.querySelector('#AvailableLogs').addEventListener("value-changed", function (e) {
            console.log('logged' + e.target.value);
            interopFunctions.searchDevicesComponent.invokeMethodAsync('OnAvailableLogDopDownValueChanged', e.target.value);
        });
    }
}

// Notify role
interopFunctions.setRole = (role) => {
    PostMessageFromJSToWPF("Role", role);
}

interopFunctions.LogCollectionInitiatedNotification = () => {
    console.log("interopFunctions.LogCollectionInitiatedNotification is called...");
    document.querySelector('#LogCollectionInitiatedNotification').visible = true;
}

interopFunctions.LogCollectionCompletedNotification = () => {
    console.log("interopFunctions.LogCollectionCompletedNotification is called...");
    document.querySelector('#LogCollectionCompletedNotification').visible = true;
}

interopFunctions.PackageDownloadCompletedNotification = () => {
    console.log("interopFunctions.PackageDownloadCompletedNotification is called...");
    document.querySelector('#PackageDownloadCompletedNotification').visible = true;
}

interopFunctions.PackageDownloadInitiatedNotification = () => {
    console.log("interopFunctions.PackageDownloadInitiatedNotification is called...");
    document.querySelector('#PackageDownloadInitiatedNotification').visible = true;
}

interopFunctions.PackageDownloadFailureNotification = () => {
    console.log("interopFunctions.PackageDownloadFailureNotification is called...");
    document.querySelector('#PackageDownloadFailureNotification').visible = true;
}

interopFunctions.DownloadFailureNotification = () => {
    console.log("interopFunctions.DownloadFailureNotification is called...");
    document.querySelector('#DownloadFailureNotification').visible = true;
}

interopFunctions.DownloadNotPossibleNotification = () => {
    console.log("interopFunctions.DownloadNotPossibleNotification is called...");
    document.querySelector('#DownloadNotPossibleNotification').visible = true;
}

interopFunctions.LogCollectionFailureNotification = () => {
    console.log("interopFunctions.LogCollectionFailureNotification is called...");
    document.querySelector('#LogCollectionFailureNotification').visible = true;
}

interopFunctions.LogCollectionTimeoutNotification = () => {
    console.log("interopFunctions.LogCollectionTimeoutNotification is called...");
    document.querySelector('#LogCollectionTimeoutNotification').visible = true;
}

interopFunctions.ActivateTab = (tabName) => {
    console.log("interopFunctions.ActivateTab is called... with paramter " + tabName);

    if (tabName === "RemoteAccess") {
        // Activate Remote Access tab and deactivate Collect Logs and Software Distribution tabs.
        document.querySelector('#RemoteAccess').active = true;
        document.querySelector('#CollectLogs').active = false;
        document.querySelector('#SoftwareDistribution').active = false;

        // Show Remote Access tab content and Hide Collect Logs and Software Distribution tab contents.
        document.querySelector('#RemoteAccessTabContent').style = "";
        document.querySelector('#CollectLogsTabContent').style.display = "none";
        document.querySelector('#SoftwareDistributionTabContent').style.display = "none";
    }
    else if (tabName === "CollectLogs") {
        // Activate Collect Logs tab and deactivate Remote Access and Software Distribution tabs.
        document.querySelector('#RemoteAccess').active = false;
        document.querySelector('#CollectLogs').active = true;
        document.querySelector('#SoftwareDistribution').active = false;

        // Show Collect Logs tab content and Hide Remote Access and Software Distribution tab contents.
        document.querySelector('#RemoteAccessTabContent').style.display = "none";
        document.querySelector('#CollectLogsTabContent').style = "";
        document.querySelector('#SoftwareDistributionTabContent').style.display = "none";
    }
    else if (tabName === "SoftwareDistribution") {
        // Activate Software Distribution tab and deactivate Remote Access and Collect Logs tabs.
        document.querySelector('#RemoteAccess').active = false;
        document.querySelector('#CollectLogs').active = false;
        document.querySelector('#SoftwareDistribution').active = true;

        // Show Software Distribution tab content and Hide Remote Access and Collect Logs tab contents.
        document.querySelector('#RemoteAccessTabContent').style.display = "none";
        document.querySelector('#CollectLogsTabContent').style.display = "none";
        document.querySelector('#SoftwareDistributionTabContent').style = "";
    }
}

interopFunctions.Display = (id, display) => {
    console.log("interopFunctions.Display is called with paramters id: " + id + " display: " + display);

    if (display === true) {
        // Show control of specific id
        document.querySelector('#' + id).style = "";
    }
    else {
        // Hide control of specific id
        document.querySelector('#' + id).style.display = "none";
    }
}

interopFunctions.setUserName = (userName) => {
    PostMessageFromJSToWPF("UserName", userName);
}

interopFunctions.logoutSucceeded = (status) => {
    console.log("interopFunctions.logoutSucceeded called...");
    PostMessageFromJSToWPF("LogoutSucceeded", status);
}

interopFunctions.deleteConfirmationDialog = (option) => {
    if (option == "Show") {
        document.querySelector('#delete-item').visible = true;
    }
    else if (option == "Hide") {
        document.querySelector('#delete-item').visible = false;
    }
}

interopFunctions.agentStatusDialog = (option) => {
    if (option == "Show") {
        document.querySelector('#agent-status').visible = true;
    }
    else if (option == "Hide") {
        document.querySelector('#agent-status').visible = false;
    }
}

interopFunctions.clearSelectedUUIDValue = () => {
    document.querySelector('sh-dropdown').value = "";
}

interopFunctions.startSession = (sessionDetials) => {
    console.log("interopFunctions.startSession called...");
    PostMessageFromJSToWPF("StartSession", sessionDetials);
}

interopFunctions.setRegion = (region) => {
    console.log("interopFunctions.setRegion called...");
    PostMessageFromJSToWPF("Region", region);
}

//#endregion

//#region Call WPF methods from JavaScript
function PostMessageFromJSToWPF(key, value) {
    message = JSON.stringify({ Type: key, Value: value });
    console.log("PostMessageFromJSToWPF: " + message);
    window.chrome.webview.postMessage(message);
}
//#endregion

//#region Call JavaScript methods from WPF
interopFunctions.searchDevices = (value) => {
    console.log(value);

    interopFunctions.navigationComponent.invokeMethodAsync('OnSearchDevices', value);
}

interopFunctions.postMessageToWebContent = (value) => {
    console.log(value);
    message = JSON.parse(value);
    console.log("Message Type: ", message.Type);
    console.log("Message Value", message.Value);

    if (message.Type === "LogoutInitiated") {
        console.log("Before invokeMethodAsync")
        console.log(interopFunctions.loginComponent);
        interopFunctions.loginComponent.invokeMethodAsync('OnLogoutInitiated');
        console.log("After invokeMethodAsync")
    }
    else if (message.Type === "ThemeChanged") {
        ChangeTheme(message.Value);
    }
    else if (message.Type === "SearchDevices" || message.Type === "Registration" || message.Type === "SoftwareDistribution") {
        interopFunctions.mainLayoutComponent.invokeMethodAsync('Navigate', message.Type);
    }
    else if (message.Type === "CloseSession") {
        interopFunctions.searchDevicesComponent.invokeMethodAsync('CloseSession');
    }

}


//#endregion

//#region Call Blazor components from JavaScript

//endregion